class_name BattleAttackResolutionService
extends RefCounted

const BattleState := preload("res://battle/core/battle_state.gd")
const BattleParticipant := preload("res://battle/core/battle_participant.gd")
const BattleWeaponCatalog := preload("res://battle/combat/battle_weapon_catalog.gd")
const BattleWeaponDefinition := preload("res://battle/combat/battle_weapon_definition.gd")
const BattleFireControlService := preload("res://battle/combat/battle_fire_control_service.gd")
const BattleFireControlResult := preload("res://battle/combat/battle_fire_control_result.gd")
const BattleAttackProfile := preload("res://battle/combat/battle_attack_profile.gd")
const BattleAttackEvent := preload("res://battle/combat/battle_attack_event.gd")
const BattleAttackResult := preload("res://battle/combat/battle_attack_result.gd")
const BattleCoverProtectionService := preload("res://battle/geometry/battle_cover_protection_service.gd")
const BattleCoverProtectionResult := preload("res://battle/geometry/battle_cover_protection_result.gd")
const BattleCoverCombatEffectService := preload("res://battle/combat/battle_cover_combat_effect_service.gd")
const BattleCoverCombatEffectResult := preload("res://battle/combat/battle_cover_combat_effect_result.gd")
const BattleCombatBehaviorCatalog := preload("res://battle/combat/battle_combat_behavior_catalog.gd")
const BattleCombatConsequenceService := preload("res://battle/combat/battle_combat_consequence_service.gd")
const BattleCombatConsequenceResult := preload("res://battle/combat/battle_combat_consequence_result.gd")
const BattleShotgunRangeFalloffService := preload("res://battle/combat/battle_shotgun_range_falloff_service.gd")
const BattleShotgunRangeFalloffResult := preload("res://battle/combat/battle_shotgun_range_falloff_result.gd")


static func resolve_attack(
	battle_state: BattleState,
	source_participant_id: String,
	target_participant_id: String,
	outcome_roll: float
) -> BattleAttackResult:
	if battle_state == null:
		return BattleAttackResult.failed(
			"null_battle_state",
			"Battle attack resolution failed: battle_state is null."
		)
	if battle_state.battle_phase != "active":
		return BattleAttackResult.failed(
			"battle_not_active",
			"Battle attack resolution failed: battle phase is '%s', not active." % battle_state.battle_phase
		)
	if battle_state.battlefield_geometry == null:
		return BattleAttackResult.failed(
			"missing_battlefield_geometry",
			"Battle attack resolution failed: battlefield geometry is missing."
		)
	if not battle_state.has_valid_geometry():
		return BattleAttackResult.failed(
			"invalid_battlefield_geometry",
			"Battle attack resolution failed: battlefield geometry is invalid."
		)
	if source_participant_id.is_empty():
		return BattleAttackResult.failed(
			"empty_source_id",
			"Battle attack resolution failed: source participant id is empty."
		)
	if target_participant_id.is_empty():
		return BattleAttackResult.failed(
			"empty_target_id",
			"Battle attack resolution failed: target participant id is empty."
		)
	if not BattleAttackProfile.is_valid_outcome_roll(outcome_roll):
		return BattleAttackResult.failed(
			"invalid_outcome_roll",
			"Battle attack resolution failed: outcome_roll is invalid."
		)
	if not battle_state.has_participant(source_participant_id):
		return BattleAttackResult.failed(
			"source_not_found",
			"Battle attack resolution failed: source participant was not found."
		)
	if not battle_state.has_participant(target_participant_id):
		return BattleAttackResult.failed(
			"target_not_found",
			"Battle attack resolution failed: target participant was not found."
		)
	var eligibility: BattleFireControlResult = BattleFireControlService.evaluate_participant_target_eligibility(
		battle_state,
		source_participant_id,
		target_participant_id
	)
	if eligibility == null or not eligibility.success:
		var error_code: String = "fire_eligibility_failed"
		var error_message: String = "Battle attack resolution failed: fire eligibility could not be evaluated."
		if eligibility != null:
			if not eligibility.error_code.is_empty():
				error_code = eligibility.error_code
			if not eligibility.error_message.is_empty():
				error_message = eligibility.error_message
		return BattleAttackResult.failed(error_code, error_message)
	if not eligibility.can_fire:
		return BattleAttackResult.rejected(eligibility.rejection_code)
	var source: BattleParticipant = battle_state.get_participant(source_participant_id)
	var target: BattleParticipant = battle_state.get_participant(target_participant_id)
	if source == null or target == null or source.weapon_state == null:
		return BattleAttackResult.failed(
			"invalid_weapon_state",
			"Battle attack resolution failed: participant weapon state is invalid."
		)
	var definition: BattleWeaponDefinition = BattleWeaponCatalog.for_participant(source)
	if definition == null:
		return BattleAttackResult.failed(
			"invalid_weapon_state",
			"Battle attack resolution failed: weapon definition is missing."
		)
	var profile: BattleAttackProfile = definition.attack_profile()
	var shotgun_falloff: BattleShotgunRangeFalloffResult = null
	if source.has_battle_position and target.has_battle_position:
		shotgun_falloff = BattleShotgunRangeFalloffService.apply(
			definition,
			source.battle_position.distance_to(target.battle_position)
		)
	else:
		shotgun_falloff = BattleShotgunRangeFalloffService.apply(definition, 0.0)
	if shotgun_falloff != null:
		profile = shotgun_falloff.attack_profile()
	if profile == null or not profile.is_valid():
		return BattleAttackResult.failed(
			"invalid_attack_profile",
			"Battle attack resolution failed: attack profile is invalid."
		)
	var protection: BattleCoverProtectionResult = BattleCoverProtectionService.query_protection(
		battle_state.battlefield_geometry,
		target,
		source.battle_position
	)
	var protection_factor: float = 0.0
	if protection != null and protection.has_applicable_cover:
		protection_factor = protection.protection_factor
	var cover_effect: BattleCoverCombatEffectResult = BattleCoverCombatEffectService.apply(
		outcome_roll,
		protection_factor
	)
	var resolved_roll: float = outcome_roll
	if cover_effect != null:
		resolved_roll = cover_effect.post_cover_roll
	# Range/handling change shot quality. They never create a separate kill lottery.
	if not definition.model_id.is_empty():
		var distance: float = source.battle_position.distance_to(target.battle_position)
		var far: float = 0.0 if source.weapon_type == "shotgun" else clampf((distance / definition.max_range - 0.55) / 0.45, 0.0, 1.0)
		var handling: float = minf(0.20, source.weapon_recoil)
		if source.weapon_type == "sniper" and distance < 12.0: handling += 0.15 * (1.0 - distance / 12.0)
		resolved_roll *= maxf(0.45, 1.0 - far * (0.08 if source.weapon_type == "sniper" else 0.18) - handling)
	var hit_quality: String = profile.resolve_hit_quality(resolved_roll)
	if hit_quality.is_empty():
		return BattleAttackResult.failed(
			"invalid_attack_profile",
			"Battle attack resolution failed: hit quality could not be resolved."
		)
	var trauma_applied: float = definition.trauma_for_hit_quality(hit_quality)
	if shotgun_falloff != null:
		trauma_applied = shotgun_falloff.trauma_for_hit_quality(hit_quality)
	if not is_finite(trauma_applied) or trauma_applied < 0.0:
		trauma_applied = 0.0
	var fire_rate_multiplier: float = 1.0
	if source.is_wounded:
		fire_rate_multiplier = BattleCombatBehaviorCatalog.WOUNDED_FIRE_RATE_MULTIPLIER
	var target_was_wounded: bool = target.is_wounded
	var target_was_alive: bool = target.is_alive
	if not BattleFireControlService.commit_shot(source, definition, fire_rate_multiplier):
		return BattleAttackResult.failed(
			"shot_commit_failed",
			"Battle attack resolution failed: weapon cycling could not be committed."
		)
	source.weapon_recoil = minf(0.20, source.weapon_recoil + definition.recoil_per_shot)
	var consequence: BattleCombatConsequenceResult = BattleCombatConsequenceService.apply_trauma(
		battle_state,
		target,
		trauma_applied
	)
	if consequence == null or not consequence.success:
		return BattleAttackResult.failed(
			"consequence_failed",
			"Battle attack resolution failed: trauma consequence could not be applied."
		)
	var outcome: String = BattleAttackProfile.derive_presentation_outcome(
		hit_quality,
		target_was_alive,
		target.is_alive,
		target_was_wounded,
		target.is_wounded
	)
	var attack_event: BattleAttackEvent = BattleAttackEvent.new(
		source.participant_id,
		target.participant_id,
		source.weapon_state.weapon_type_id,
		outcome,
		resolved_roll,
		target_was_wounded,
		target.is_wounded,
		target_was_alive,
		target.is_alive
	)
	attack_event.weapon_hand = source.weapon_state.last_fired_hand
	attack_event.hit_quality = hit_quality
	attack_event.trauma_applied = trauma_applied
	attack_event.elapsed_time_seconds = battle_state.elapsed_time_seconds
	if source.has_battle_position:
		attack_event.source_position = source.battle_position
		attack_event.has_source_position = true
	if target.has_battle_position:
		attack_event.target_position = target.battle_position
		attack_event.has_target_position = true
	battle_state.record_combat_feedback_event(attack_event)
	return BattleAttackResult.executed(attack_event)
