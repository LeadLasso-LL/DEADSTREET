class_name BattleCombatCoverEvaluationService
extends RefCounted

# Shared combat-cover usefulness query. Healthy and wounded selection consume this.
# Does not mutate battle state, occupancy, or cover mitigation math.

const BattleState := preload("res://battle/core/battle_state.gd")
const BattleParticipant := preload("res://battle/core/battle_participant.gd")
const BattlefieldGeometry := preload("res://battle/geometry/battlefield_geometry.gd")
const BattleCoverSlot := preload("res://battle/geometry/battle_cover_slot.gd")
const BattleCoverObject := preload("res://battle/geometry/battle_cover_object.gd")
const BattleCoverService := preload("res://battle/geometry/battle_cover_service.gd")
const BattleCoverProtectionService := preload("res://battle/geometry/battle_cover_protection_service.gd")
const BattleCoverProtectionResult := preload("res://battle/geometry/battle_cover_protection_result.gd")
const BattleLineOfSightService := preload("res://battle/combat/battle_line_of_sight_service.gd")
const BattleLineOfSightResult := preload("res://battle/combat/battle_line_of_sight_result.gd")
const BattleNavigationService := preload("res://battle/navigation/battle_navigation_service.gd")
const BattleNavigationResult := preload("res://battle/navigation/battle_navigation_result.gd")
const BattleCombatCoverEvaluation := preload("res://battle/combat/battle_combat_cover_evaluation.gd")
const BattleCombatBehaviorCatalog := preload("res://battle/combat/battle_combat_behavior_catalog.gd")
const BattleCombatBehaviorProfile := preload("res://battle/combat/battle_combat_behavior_profile.gd")
const BattleWeaponCatalog := preload("res://battle/combat/battle_weapon_catalog.gd")
const BattleWeaponDefinition := preload("res://battle/combat/battle_weapon_definition.gd")

# AI usefulness only. Does not change cover mitigation.
const USEFUL_PROTECTION_FACTOR := 0.50


static func is_useful_protection_factor(protection_factor: float) -> bool:
	if not is_finite(protection_factor):
		return false
	return protection_factor > USEFUL_PROTECTION_FACTOR or is_equal_approx(
		protection_factor,
		USEFUL_PROTECTION_FACTOR
	)


static func relevant_cover_threat(
	battle_state: BattleState,
	participant: BattleParticipant
) -> BattleParticipant:
	if battle_state == null or participant == null:
		return null
	var from_priority: BattleParticipant = _living_hostile_by_id(
		battle_state,
		participant,
		participant.player_priority_target_id
	)
	if from_priority != null:
		return from_priority
	var from_current: BattleParticipant = _living_hostile_by_id(
		battle_state,
		participant,
		participant.target_participant_id
	)
	if from_current != null:
		return from_current
	return _nearest_living_hostile(battle_state, participant)


static func rank_legal_slots_on_cover_object(
	battle_state: BattleState,
	participant: BattleParticipant,
	cover_object_id: String,
	hostile: BattleParticipant
) -> Array[BattleCoverSlot]:
	var ranked_slots: Array[BattleCoverSlot] = []
	if battle_state == null or participant == null or cover_object_id.is_empty():
		return ranked_slots
	if battle_state.battlefield_geometry == null:
		return ranked_slots
	if not battle_state.battlefield_geometry.has_cover_object(cover_object_id):
		return ranked_slots
	var cover_object: BattleCoverObject = battle_state.battlefield_geometry.get_cover_object(
		cover_object_id
	)
	if cover_object == null:
		return ranked_slots
	var slot_ids: Array[String] = []
	for slot_id: String in cover_object.slot_ids:
		slot_ids.append(slot_id)
	slot_ids.sort()
	var ranked: Array[BattleCombatCoverEvaluation] = []
	var has_threat: bool = hostile != null and _is_positioned(hostile)
	for slot_id: String in slot_ids:
		var slot: BattleCoverSlot = battle_state.battlefield_geometry.get_cover_slot(slot_id)
		if slot == null or not slot.is_valid():
			continue
		if slot.cover_object_id != cover_object_id:
			continue
		if not _slot_is_legal_for_participant(participant, slot):
			continue
		var evaluation: BattleCombatCoverEvaluation = evaluate_slot(
			battle_state,
			participant,
			slot,
			hostile,
			false,
			false,
			INF
		)
		if evaluation == null or not evaluation.legal:
			continue
		_insert_object_cover_ranked(ranked, evaluation, has_threat)
	for evaluation: BattleCombatCoverEvaluation in ranked:
		var ranked_slot: BattleCoverSlot = battle_state.battlefield_geometry.get_cover_slot(
			evaluation.slot_id
		)
		if ranked_slot != null:
			ranked_slots.append(ranked_slot)
	return ranked_slots


static func occupied_cover_is_suitable(
	battle_state: BattleState,
	participant: BattleParticipant,
	hostile: BattleParticipant,
	require_weapon_range: bool = false
) -> bool:
	if participant == null or battle_state == null or battle_state.battlefield_geometry == null:
		return false
	if participant.occupied_cover_slot_id.is_empty():
		return false
	var slot: BattleCoverSlot = battle_state.battlefield_geometry.get_cover_slot(
		participant.occupied_cover_slot_id
	)
	if slot == null or slot.occupied_by_participant_id != participant.participant_id:
		return false
	if hostile == null or not hostile.is_alive:
		return true
	if not _is_positioned(hostile):
		return true
	var evaluation: BattleCombatCoverEvaluation = evaluate_slot(
		battle_state,
		participant,
		slot,
		hostile,
		false,
		require_weapon_range,
		INF
	)
	if evaluation == null:
		return false
	if not evaluation.legal:
		return false
	if not evaluation.has_line_of_sight:
		return false
	if not evaluation.has_useful_direction:
		return false
	if require_weapon_range and not evaluation.in_weapon_max_range:
		return false
	return true


# Equivalent to evaluate_slot(...).legal && .has_useful_direction.
# Route retention does not consume LOS, weapon range, movement or reachability.
static func slot_is_legal_and_protective(
	participant: BattleParticipant,
	slot: BattleCoverSlot,
	hostile: BattleParticipant
) -> bool:
	if not _slot_is_legal_for_participant(participant, slot) or not _is_positioned(hostile):
		return false
	var protection: BattleCoverProtectionResult = BattleCoverProtectionService.query_slot_protection(
		slot, hostile.battle_position
	)
	return protection != null and protection.has_applicable_cover and is_useful_protection_factor(protection.protection_factor)


static func occupied_cover_still_protects(
	battle_state: BattleState,
	participant: BattleParticipant,
	hostile: BattleParticipant
) -> bool:
	if participant == null or battle_state == null or battle_state.battlefield_geometry == null:
		return false
	if participant.occupied_cover_slot_id.is_empty():
		return false
	var slot: BattleCoverSlot = battle_state.battlefield_geometry.get_cover_slot(
		participant.occupied_cover_slot_id
	)
	if slot == null or slot.occupied_by_participant_id != participant.participant_id:
		return false
	if hostile == null or not hostile.is_alive or not _is_positioned(hostile):
		return true
	var protection: BattleCoverProtectionResult = BattleCoverProtectionService.query_slot_protection(
		slot,
		hostile.battle_position
	)
	if protection == null or not protection.has_applicable_cover:
		return false
	return is_useful_protection_factor(protection.protection_factor)


static func select_best_combat_usable_slot(
	battle_state: BattleState,
	participant: BattleParticipant,
	hostile: BattleParticipant,
	require_weapon_range: bool,
	max_move_distance: float = INF
) -> BattleCoverSlot:
	var ranked: Array[BattleCombatCoverEvaluation] = rank_combat_usable(
		battle_state,
		participant,
		hostile,
		require_weapon_range,
		max_move_distance
	)
	return first_reachable_ranked_slot(battle_state, participant, ranked, false)


static func rank_combat_usable_within_radius(
	battle_state: BattleState,
	participant: BattleParticipant,
	hostile: BattleParticipant,
	require_weapon_range: bool,
	origin: Vector2,
	radius: float
) -> Array[BattleCombatCoverEvaluation]:
	var ranked: Array[BattleCombatCoverEvaluation] = []
	if not BattlefieldGeometry.is_finite_point(origin) or not is_finite(radius) or radius < 0.0:
		return ranked
	if battle_state == null or participant == null or battle_state.battlefield_geometry == null:
		return ranked
	for slot_id: String in battle_state.battlefield_geometry.get_cover_slot_ids_in_radius(origin, radius):
		var slot: BattleCoverSlot = battle_state.battlefield_geometry.get_cover_slot(slot_id)
		if slot == null or not slot.is_valid():
			continue
		var distance: float = slot.position.distance_to(origin)
		if not is_finite(distance):
			continue
		if distance > radius and not is_equal_approx(distance, radius):
			continue
		var evaluation: BattleCombatCoverEvaluation = evaluate_slot(
			battle_state,
			participant,
			slot,
			hostile,
			false,
			require_weapon_range,
			INF
		)
		if evaluation == null or not evaluation.combat_usable:
			continue
		_insert_ranked(ranked, evaluation, false)
	return ranked


static func rank_combat_usable(
	battle_state: BattleState,
	participant: BattleParticipant,
	hostile: BattleParticipant,
	require_weapon_range: bool,
	max_move_distance: float = INF
) -> Array[BattleCombatCoverEvaluation]:
	var ranked: Array[BattleCombatCoverEvaluation] = []
	for evaluation: BattleCombatCoverEvaluation in _evaluate_rank_candidates(
		battle_state,
		participant,
		hostile,
		false,
		require_weapon_range,
		max_move_distance
	):
		if evaluation == null or not evaluation.combat_usable:
			continue
		_insert_ranked(ranked, evaluation, false)
	return ranked


static func rank_healthy_role(
	battle_state: BattleState,
	participant: BattleParticipant,
	hostile: BattleParticipant,
	weapon_type_id: String,
	require_weapon_range: bool,
	max_move_distance: float
) -> Array[BattleCombatCoverEvaluation]:
	var prefer_band: bool = (
		weapon_type_id == BattleWeaponCatalog.WEAPON_RIFLE
		or weapon_type_id == BattleWeaponCatalog.WEAPON_SNIPER
	)
	var ranked: Array[BattleCombatCoverEvaluation] = []
	for evaluation: BattleCombatCoverEvaluation in _evaluate_rank_candidates(
		battle_state,
		participant,
		hostile,
		false,
		require_weapon_range,
		max_move_distance
	):
		if evaluation == null or not evaluation.combat_usable:
			continue
		if prefer_band:
			var slot_range: float = INF
			if hostile != null and _is_positioned(hostile):
				var slot: BattleCoverSlot = battle_state.battlefield_geometry.get_cover_slot(evaluation.slot_id)
				if slot != null:
					slot_range = slot.position.distance_to(hostile.battle_position)
			evaluation.band_error = BattleCombatBehaviorCatalog.participant_band_error(participant,
				slot_range
			)
			if not is_finite(evaluation.band_error):
				continue
			evaluation.in_band = is_equal_approx(evaluation.band_error, 0.0)
		_insert_ranked(ranked, evaluation, prefer_band)
	return ranked


# Closing rank runs on decision/invalidation only. Protection vs the current
# threat first, then forward progress, then move distance.
static func rank_closing_cover(
	battle_state: BattleState,
	participant: BattleParticipant,
	hostile: BattleParticipant,
	weapon_type_id: String,
	max_move_distance: float
) -> Array[BattleCombatCoverEvaluation]:
	var ranked: Array[BattleCombatCoverEvaluation] = []
	if battle_state == null or participant == null or battle_state.battlefield_geometry == null:
		return ranked
	if not _is_positioned(participant) or hostile == null or not _is_positioned(hostile):
		return ranked
	if not is_finite(max_move_distance) or max_move_distance <= 0.0:
		return ranked
	var current_range: float = participant.battle_position.distance_to(hostile.battle_position)
	if not is_finite(current_range):
		return ranked
	var preferred_min: float = 0.0
	var profile: BattleCombatBehaviorProfile = BattleCombatBehaviorCatalog.for_participant(participant)
	if profile != null:
		preferred_min = profile.preferred_min_distance
	var progress_epsilon: float = BattleCombatBehaviorCatalog.CLOSING_PROGRESS_EPSILON
	for slot_id: String in battle_state.battlefield_geometry.get_cover_slot_ids_in_radius(participant.battle_position, max_move_distance):
		var slot: BattleCoverSlot = battle_state.battlefield_geometry.get_cover_slot(slot_id)
		if slot == null or not slot.is_valid():
			continue
		var slot_range: float = slot.position.distance_to(hostile.battle_position)
		if not is_finite(slot_range):
			continue
		if (
			is_finite(preferred_min)
			and preferred_min > 0.0
			and slot_range < preferred_min
			and not is_equal_approx(slot_range, preferred_min)
		):
			continue
		var progress: float = current_range - slot_range
		if not is_finite(progress):
			continue
		if progress < progress_epsilon and not is_equal_approx(progress, progress_epsilon):
			continue
		var prepared: BattleCoverProtectionResult = _rank_candidate_protection(participant,slot,hostile,max_move_distance)
		if prepared == null:
			continue
		var evaluation: BattleCombatCoverEvaluation = evaluate_slot(
			battle_state,
			participant,
			slot,
			hostile,
			false,
			false,
			max_move_distance,
			prepared
		)
		if evaluation == null or not evaluation.legal:
			continue
		if not is_finite(evaluation.move_distance):
			continue
		if (
			evaluation.move_distance > max_move_distance
			and not is_equal_approx(evaluation.move_distance, max_move_distance)
		):
			continue
		if not evaluation.has_useful_direction:
			continue
		evaluation.closing_progress = progress
		_insert_closing_ranked(ranked, evaluation)
	return ranked


# IN_USEFUL_RANGE SMG/shotgun: survive and fight. Nearby useful directional
# cover outranks farther equivalent or marginally better slots.
static func rank_short_range_in_useful_range(
	battle_state: BattleState,
	participant: BattleParticipant,
	hostile: BattleParticipant,
	max_move_distance: float
) -> Array[BattleCombatCoverEvaluation]:
	var ranked: Array[BattleCombatCoverEvaluation] = []
	for evaluation: BattleCombatCoverEvaluation in _evaluate_rank_candidates(
		battle_state,
		participant,
		hostile,
		false,
		true,
		max_move_distance
	):
		if evaluation == null or not evaluation.combat_usable:
			continue
		_insert_near_first_ranked(ranked, evaluation)
	return ranked


# OUT_OF_RANGE SMG/shotgun fallback when closing cover is unavailable:
# nearby useful protective cover, even if it is still outside weapon max range.
static func rank_short_range_nearby_useful(
	battle_state: BattleState,
	participant: BattleParticipant,
	hostile: BattleParticipant,
	require_weapon_range: bool,
	max_move_distance: float
) -> Array[BattleCombatCoverEvaluation]:
	var ranked: Array[BattleCombatCoverEvaluation] = []
	for evaluation: BattleCombatCoverEvaluation in _evaluate_rank_candidates(
		battle_state,
		participant,
		hostile,
		false,
		require_weapon_range,
		max_move_distance
	):
		if evaluation == null or not evaluation.combat_usable:
			continue
		_insert_near_first_ranked(ranked, evaluation)
	return ranked


# OUT_OF_RANGE SMG/shotgun staging: advance toward useful range, but take the
# nearer sufficiently protective progressive slot instead of leaping farther.
static func rank_short_range_out_of_range_staging(
	battle_state: BattleState,
	participant: BattleParticipant,
	hostile: BattleParticipant,
	weapon_type_id: String,
	max_move_distance: float
) -> Array[BattleCombatCoverEvaluation]:
	var ranked: Array[BattleCombatCoverEvaluation] = []
	if battle_state == null or participant == null or battle_state.battlefield_geometry == null:
		return ranked
	if not _is_positioned(participant) or hostile == null or not _is_positioned(hostile):
		return ranked
	if not is_finite(max_move_distance) or max_move_distance <= 0.0:
		return ranked
	var current_range: float = participant.battle_position.distance_to(hostile.battle_position)
	if not is_finite(current_range):
		return ranked
	var preferred_min: float = 0.0
	var profile: BattleCombatBehaviorProfile = BattleCombatBehaviorCatalog.for_participant(participant)
	if profile != null:
		preferred_min = profile.preferred_min_distance
	var progress_epsilon: float = BattleCombatBehaviorCatalog.CLOSING_PROGRESS_EPSILON
	for slot_id: String in battle_state.battlefield_geometry.get_cover_slot_ids_in_radius(participant.battle_position, max_move_distance):
		var slot: BattleCoverSlot = battle_state.battlefield_geometry.get_cover_slot(slot_id)
		if slot == null or not slot.is_valid():
			continue
		var slot_range: float = slot.position.distance_to(hostile.battle_position)
		if not is_finite(slot_range):
			continue
		if (
			is_finite(preferred_min)
			and preferred_min > 0.0
			and slot_range < preferred_min
			and not is_equal_approx(slot_range, preferred_min)
		):
			continue
		var progress: float = current_range - slot_range
		if not is_finite(progress):
			continue
		if progress < progress_epsilon and not is_equal_approx(progress, progress_epsilon):
			continue
		var prepared: BattleCoverProtectionResult = _rank_candidate_protection(participant,slot,hostile,max_move_distance)
		if prepared == null:
			continue
		var evaluation: BattleCombatCoverEvaluation = evaluate_slot(
			battle_state,
			participant,
			slot,
			hostile,
			false,
			false,
			max_move_distance,
			prepared
		)
		if evaluation == null or not evaluation.legal:
			continue
		if not is_finite(evaluation.move_distance):
			continue
		if (
			evaluation.move_distance > max_move_distance
			and not is_equal_approx(evaluation.move_distance, max_move_distance)
		):
			continue
		if not evaluation.has_useful_direction:
			continue
		evaluation.closing_progress = progress
		_insert_staging_ranked(ranked, evaluation)
	return ranked


static func evaluate_all(
	battle_state: BattleState,
	participant: BattleParticipant,
	hostile: BattleParticipant,
	require_reachable: bool,
	require_weapon_range: bool,
	max_move_distance: float = INF
) -> Array[BattleCombatCoverEvaluation]:
	var evaluations: Array[BattleCombatCoverEvaluation] = []
	if battle_state == null or participant == null or battle_state.battlefield_geometry == null:
		return evaluations
	for slot_id: String in battle_state.battlefield_geometry.get_sorted_cover_slot_ids():
		var slot: BattleCoverSlot = battle_state.battlefield_geometry.get_cover_slot(slot_id)
		if slot == null:
			continue
		evaluations.append(
			evaluate_slot(
				battle_state,
				participant,
				slot,
				hostile,
				require_reachable,
				require_weapon_range,
				max_move_distance
			)
		)
	return evaluations


static func evaluate_slot(
	battle_state: BattleState,
	participant: BattleParticipant,
	slot: BattleCoverSlot,
	hostile: BattleParticipant,
	require_reachable: bool,
	require_weapon_range: bool,
	max_move_distance: float = INF,
	prepared_protection: BattleCoverProtectionResult = null
) -> BattleCombatCoverEvaluation:
	var evaluation: BattleCombatCoverEvaluation = BattleCombatCoverEvaluation.new()
	if slot != null:
		evaluation.slot_id = slot.cover_slot_id
	if participant == null or slot == null or not slot.is_valid():
		return evaluation
	evaluation.legal = _slot_is_legal_for_participant(participant, slot)
	evaluation.move_distance = INF
	if _is_positioned(participant) and BattlefieldGeometry.is_finite_point(slot.position):
		evaluation.move_distance = participant.battle_position.distance_to(slot.position)
	var within_seek: bool = true
	if is_finite(max_move_distance):
		within_seek = (
			is_finite(evaluation.move_distance)
			and (
				evaluation.move_distance < max_move_distance
				or is_equal_approx(evaluation.move_distance, max_move_distance)
			)
		)
	if hostile != null and _is_positioned(hostile):
		var protection: BattleCoverProtectionResult = prepared_protection
		if protection == null:
			protection = BattleCoverProtectionService.query_slot_protection(slot,hostile.battle_position)
		if protection != null and protection.has_applicable_cover:
			evaluation.protection_factor = protection.protection_factor
			evaluation.alignment_dot = protection.alignment_dot
	evaluation.has_useful_direction = is_useful_protection_factor(evaluation.protection_factor)
	if hostile != null and _is_positioned(hostile) and battle_state != null:
		var los: BattleLineOfSightResult = BattleLineOfSightService.check_segment(
			battle_state,
			slot.position,
			hostile.battle_position
		)
		if los != null and los.success:
			evaluation.has_line_of_sight = los.has_line_of_sight
			evaluation.blocking_obstacle_id = los.blocking_obstacle_id
		evaluation.in_weapon_max_range = _slot_is_within_weapon_max_range(
			slot,
			hostile,
			_participant_weapon_type_id(participant)
		)
	var cheap_usable: bool = (
		evaluation.legal
		and within_seek
		and evaluation.has_useful_direction
		and evaluation.has_line_of_sight
		and (evaluation.in_weapon_max_range if require_weapon_range else true)
	)
	evaluation.reachable = false
	if cheap_usable:
		if (
			is_finite(evaluation.move_distance)
			and evaluation.move_distance <= BattleCoverService.COVER_OCCUPANCY_EPSILON
		):
			evaluation.reachable = true
		elif require_reachable:
			evaluation.reachable = _slot_is_reachable(battle_state, participant, slot)
		else:
			evaluation.reachable = true
	evaluation.combat_usable = cheap_usable and evaluation.reachable
	return evaluation


static func first_reachable_ranked_slot(
	battle_state: BattleState,
	participant: BattleParticipant,
	ranked: Array[BattleCombatCoverEvaluation],
	skip_self_occupied: bool
) -> BattleCoverSlot:
	if battle_state == null or participant == null or battle_state.battlefield_geometry == null:
		return null
	for evaluation: BattleCombatCoverEvaluation in ranked:
		if evaluation == null or evaluation.slot_id.is_empty():
			continue
		var slot: BattleCoverSlot = battle_state.battlefield_geometry.get_cover_slot(evaluation.slot_id)
		if slot == null or not slot.is_valid():
			continue
		if skip_self_occupied and slot.occupied_by_participant_id == participant.participant_id:
			continue
		if _slot_is_reachable(battle_state, participant, slot):
			return slot
	return null


static func _insert_ranked(
	ranked: Array[BattleCombatCoverEvaluation],
	candidate: BattleCombatCoverEvaluation,
	prefer_band: bool
) -> void:
	var index: int = 0
	while index < ranked.size() and not _rank_less(candidate, ranked[index], prefer_band):
		index += 1
	ranked.insert(index, candidate)


static func _insert_closing_ranked(
	ranked: Array[BattleCombatCoverEvaluation],
	candidate: BattleCombatCoverEvaluation
) -> void:
	var index: int = 0
	while index < ranked.size() and not _closing_rank_less(candidate, ranked[index]):
		index += 1
	ranked.insert(index, candidate)


static func _insert_near_first_ranked(
	ranked: Array[BattleCombatCoverEvaluation],
	candidate: BattleCombatCoverEvaluation
) -> void:
	var index: int = 0
	while index < ranked.size() and not _near_first_rank_less(candidate, ranked[index]):
		index += 1
	ranked.insert(index, candidate)


static func _insert_staging_ranked(
	ranked: Array[BattleCombatCoverEvaluation],
	candidate: BattleCombatCoverEvaluation
) -> void:
	var index: int = 0
	while index < ranked.size() and not _staging_rank_less(candidate, ranked[index]):
		index += 1
	ranked.insert(index, candidate)


static func _rank_less(
	left: BattleCombatCoverEvaluation,
	right: BattleCombatCoverEvaluation,
	prefer_band: bool
) -> bool:
	if prefer_band:
		if left.in_band != right.in_band:
			return left.in_band and not right.in_band
		if not is_equal_approx(left.band_error, right.band_error):
			return left.band_error < right.band_error
	if not is_equal_approx(left.protection_factor, right.protection_factor):
		return left.protection_factor > right.protection_factor
	if not is_equal_approx(left.move_distance, right.move_distance):
		return left.move_distance < right.move_distance
	return left.slot_id < right.slot_id


static func _closing_rank_less(left: BattleCombatCoverEvaluation, right: BattleCombatCoverEvaluation) -> bool:
	if not is_equal_approx(left.protection_factor, right.protection_factor):
		return left.protection_factor > right.protection_factor
	if not is_equal_approx(left.closing_progress, right.closing_progress):
		return left.closing_progress > right.closing_progress
	if not is_equal_approx(left.move_distance, right.move_distance):
		return left.move_distance < right.move_distance
	return left.slot_id < right.slot_id


static func _near_first_rank_less(
	left: BattleCombatCoverEvaluation,
	right: BattleCombatCoverEvaluation
) -> bool:
	if not is_equal_approx(left.move_distance, right.move_distance):
		return left.move_distance < right.move_distance
	if not is_equal_approx(left.protection_factor, right.protection_factor):
		return left.protection_factor > right.protection_factor
	return left.slot_id < right.slot_id


static func _staging_rank_less(
	left: BattleCombatCoverEvaluation,
	right: BattleCombatCoverEvaluation
) -> bool:
	if not is_equal_approx(left.move_distance, right.move_distance):
		return left.move_distance < right.move_distance
	if not is_equal_approx(left.closing_progress, right.closing_progress):
		return left.closing_progress > right.closing_progress
	if not is_equal_approx(left.protection_factor, right.protection_factor):
		return left.protection_factor > right.protection_factor
	return left.slot_id < right.slot_id


static func _insert_object_cover_ranked(
	ranked: Array[BattleCombatCoverEvaluation],
	candidate: BattleCombatCoverEvaluation,
	has_threat: bool
) -> void:
	var index: int = 0
	while index < ranked.size() and not _object_cover_rank_less(candidate, ranked[index], has_threat):
		index += 1
	ranked.insert(index, candidate)


static func _object_cover_rank_less(
	left: BattleCombatCoverEvaluation,
	right: BattleCombatCoverEvaluation,
	has_threat: bool
) -> bool:
	if has_threat:
		if left.has_useful_direction != right.has_useful_direction:
			return left.has_useful_direction and not right.has_useful_direction
		if not is_equal_approx(left.protection_factor, right.protection_factor):
			return left.protection_factor > right.protection_factor
		if left.has_line_of_sight != right.has_line_of_sight:
			return left.has_line_of_sight and not right.has_line_of_sight
	if not is_equal_approx(left.move_distance, right.move_distance):
		return left.move_distance < right.move_distance
	return left.slot_id < right.slot_id


static func _living_hostile_by_id(
	battle_state: BattleState,
	participant: BattleParticipant,
	hostile_id: String
) -> BattleParticipant:
	if battle_state == null or participant == null or hostile_id.is_empty():
		return null
	if not battle_state.has_participant(hostile_id):
		return null
	var hostile: BattleParticipant = battle_state.get_participant(hostile_id)
	if hostile == null or not hostile.is_alive:
		return null
	if hostile.side_id == participant.side_id:
		return null
	if not _is_positioned(hostile):
		return null
	return hostile


static func _nearest_living_hostile(
	battle_state: BattleState,
	participant: BattleParticipant
) -> BattleParticipant:
	if battle_state == null or participant == null or not _is_positioned(participant):
		return null
	var best: BattleParticipant = null
	var best_distance: float = INF
	var ids: Array[String] = []
	for participant_id: String in battle_state.participants:
		ids.append(participant_id)
	ids.sort()
	for participant_id: String in ids:
		var hostile: BattleParticipant = _living_hostile_by_id(
			battle_state,
			participant,
			participant_id
		)
		if hostile == null:
			continue
		var distance: float = participant.battle_position.distance_squared_to(hostile.battle_position)
		if not is_finite(distance):
			continue
		if best == null or distance < best_distance:
			best = hostile
			best_distance = distance
	return best


static func _slot_is_legal_for_participant(participant: BattleParticipant, slot: BattleCoverSlot) -> bool:
	if participant == null or slot == null or not slot.is_valid():
		return false
	if slot.occupied_by_participant_id != "" and slot.occupied_by_participant_id != participant.participant_id:
		return false
	if slot.occupied_by_participant_id == participant.participant_id:
		return true
	if slot.reserved_by_participant_id != "" and slot.reserved_by_participant_id != participant.participant_id:
		return false
	return true


static func _slot_is_reachable(
	battle_state: BattleState,
	participant: BattleParticipant,
	slot: BattleCoverSlot
) -> bool:
	if participant == null or slot == null or battle_state == null:
		return false
	if not _is_positioned(participant):
		return false
	if participant.battle_position.distance_to(slot.position) <= BattleCoverService.COVER_OCCUPANCY_EPSILON:
		return true
	return BattleNavigationService.is_reachable(
		battle_state,
		participant.battle_position,
		slot.position
	)


static func _slot_is_within_weapon_max_range(
	slot: BattleCoverSlot,
	hostile: BattleParticipant,
	weapon_type_id: String
) -> bool:
	if slot == null or not slot.is_valid() or hostile == null or not _is_positioned(hostile):
		return false
	var definition: BattleWeaponDefinition = BattleWeaponCatalog.get_definition(weapon_type_id)
	if definition == null or not definition.is_valid():
		return false
	var slot_range: float = slot.position.distance_to(hostile.battle_position)
	if not is_finite(slot_range):
		return false
	return slot_range <= definition.max_range or is_equal_approx(slot_range, definition.max_range)


static func _participant_weapon_type_id(participant: BattleParticipant) -> String:
	if participant == null:
		return ""
	if participant.weapon_state != null and not participant.weapon_state.weapon_type_id.is_empty():
		return participant.weapon_state.weapon_type_id
	return participant.weapon_type


static func _is_positioned(participant: BattleParticipant) -> bool:
	if participant == null:
		return false
	if not participant.has_battle_position:
		return false
	return BattlefieldGeometry.is_finite_point(participant.battle_position)


static func _evaluate_rank_candidates(
	battle_state: BattleState,
	participant: BattleParticipant,
	hostile: BattleParticipant,
	require_reachable: bool,
	require_weapon_range: bool,
	max_move_distance: float = INF
) -> Array[BattleCombatCoverEvaluation]:
	var evaluations: Array[BattleCombatCoverEvaluation] = []
	if battle_state == null or participant == null or battle_state.battlefield_geometry == null:
		return evaluations
	var range_limit: float = INF
	if require_weapon_range:
		var definition: BattleWeaponDefinition = BattleWeaponCatalog.get_definition(_participant_weapon_type_id(participant))
		if definition == null or not definition.is_valid() or hostile == null or not _is_positioned(hostile):
			return evaluations
		range_limit = definition.max_range
	for slot_id: String in battle_state.battlefield_geometry.get_cover_slot_ids_in_radius(participant.battle_position, max_move_distance):
		var slot: BattleCoverSlot = battle_state.battlefield_geometry.get_cover_slot(slot_id)
		if require_weapon_range:
			if slot == null:
				continue
			var distance: float = slot.position.distance_to(hostile.battle_position)
			if not is_finite(distance) or (distance > range_limit and not is_equal_approx(distance,range_limit)):
				continue
		var prepared: BattleCoverProtectionResult = _rank_candidate_protection(participant,slot,hostile,max_move_distance)
		if prepared == null:
			continue
		evaluations.append(
			evaluate_slot(
				battle_state,
				participant,
				slot,
				hostile,
				require_reachable,
				require_weapon_range,
				max_move_distance,
				prepared
			)
		)
	return evaluations


# These are necessary conditions already enforced by each ranking function.
# Keep evaluate_slot/evaluate_all complete for callers inspecting rejected slots.
static func _rank_candidate_allowed(
	participant: BattleParticipant, slot: BattleCoverSlot,
	hostile: BattleParticipant, max_move_distance: float
) -> bool:
	return _rank_candidate_protection(participant,slot,hostile,max_move_distance) != null

static func _rank_candidate_protection(
	participant: BattleParticipant, slot: BattleCoverSlot,
	hostile: BattleParticipant, max_move_distance: float
) -> BattleCoverProtectionResult:
	if participant == null or slot == null or not slot.is_valid():return null
	if not _slot_is_legal_for_participant(participant,slot):return null
	if is_finite(max_move_distance):
		if not _is_positioned(participant):return null
		var distance: float = participant.battle_position.distance_to(slot.position)
		if not is_finite(distance) or (distance > max_move_distance and not is_equal_approx(distance,max_move_distance)):return null
	if hostile == null or not _is_positioned(hostile):return null
	# A slot facing away cannot meet the positive useful-cover threshold.
	# This rejects it before allocating a protection result.
	if slot.facing_direction.dot(hostile.battle_position-slot.position) < 0.0:
		return null
	var protection: BattleCoverProtectionResult = BattleCoverProtectionService.query_slot_protection(slot,hostile.battle_position)
	return protection if protection != null and protection.has_applicable_cover and is_useful_protection_factor(protection.protection_factor) else null
