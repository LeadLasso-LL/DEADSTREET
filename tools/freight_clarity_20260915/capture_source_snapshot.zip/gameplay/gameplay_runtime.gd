class_name GameplayRuntime
extends Node

const StarterWorldService := preload("res://gameplay/starter_world_service.gd")
const GameFlowController := preload("res://core/game_flow_controller.gd")
const GameFlowResult := preload("res://core/game_flow_result.gd")
const NeighborhoodHQAttackService := preload("res://campaign/missions/neighborhood_hq_attack_service.gd")
const NeighborhoodHQAttackResult := preload("res://campaign/missions/neighborhood_hq_attack_result.gd")
const MissionRequest := preload("res://campaign/missions/mission_request.gd")
const DeploymentRequest := preload("res://campaign/actions/deployment_request.gd")
const CampaignBattleSession := preload("res://battle/session/campaign_battle_session.gd")
const CampaignMapView := preload("res://gameplay/campaign_map_view.gd")
const TacticalBattleView := preload("res://gameplay/tactical_battle_view.gd")
const TacticalDeploymentController := preload("res://gameplay/tactical_deployment_controller.gd")
const TacticalOrdersController := preload("res://gameplay/tactical_orders_controller.gd")
const BattleState := preload("res://battle/core/battle_state.gd")
const BattleCombatRandom := preload("res://battle/combat/battle_combat_random.gd")

const ArmorPanel := preload("res://gameplay/armor_selection_panel.gd")
var armor_layer: CanvasLayer
var armor_surface: Control
var armor_button: Button

var game_state: GameState = null
var game_flow_controller: GameFlowController = null
var tactical_deployment_controller: TacticalDeploymentController = null
var tactical_orders_controller: TacticalOrdersController = null
# Process-local debug playtest serial. Not campaign state. Resets on runtime boot.
var manual_playtest_serial: int = 0

var _last_logged_mode: String = ""
var _pending_manual_playtest_serial: int = 0
var skip_battle_cinematics: bool = false
var _pending_combat_seed_override: int = 0


func _ready() -> void:
	game_state = StarterWorldService.create()
	var create_result: GameFlowResult = GameFlowController.create(game_state)
	if create_result == null or not create_result.success or create_result.controller == null:
		var error_code: String = "controller_create_failed"
		var error_message: String = "GameplayRuntime failed: GameFlowController could not be created."
		if create_result != null:
			if not create_result.error_code.is_empty():
				error_code = create_result.error_code
			if not create_result.error_message.is_empty():
				error_message = create_result.error_message
		push_error("%s (%s)" % [error_message, error_code])
		game_flow_controller = null
		return
	game_flow_controller = create_result.controller
	_bind_campaign_map_view()
	_sync_presentation_views()
	_build_armor_store()
	_log_boot()
	_log_mode_if_changed()


func _process(delta: float) -> void:
	_log_mode_if_changed()
	_sync_armor_store()
	if game_flow_controller == null:
		return
	var mode: String = game_flow_controller.get_current_mode()
	if mode == GameFlowController.MODE_TACTICAL_DEPLOYMENT:
		_sync_tactical_pointer()
		return
	if (
		mode != GameFlowController.MODE_TACTICAL_ACTIVE
		and mode != GameFlowController.MODE_TACTICAL_PENDING_HANDOFF
	):
		return
	var presentation_view=get_node_or_null("TacticalBattleView")
	if mode==GameFlowController.MODE_TACTICAL_PENDING_HANDOFF and presentation_view!=null and presentation_view._is_dusk_street():
		var presentation=presentation_view.battle_presentation
		if presentation!=null and not presentation.results_acknowledged:return
	game_flow_controller.advance_tactical(delta)
	_sync_tactical_orders_pointer()
	_log_mode_if_changed()


func _input(event: InputEvent) -> void:
	# A drag that ends over the HUD must still release, without clicking through it.
	if tactical_orders_controller == null or not tactical_orders_controller.dragging:
		return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and not event.pressed:
		var view = get_node_or_null("TacticalBattleView")
		if view == null:
			return
		var layer = view.get_node_or_null("CommandHudLayer")
		if layer == null:
			return
		var hud = layer.get_child(0)
		if hud.visible and hud.surface.get_global_rect().has_point(event.position):
			tactical_orders_controller.dragging = false
			get_viewport().set_input_as_handled()


func _unhandled_input(event: InputEvent) -> void:
	if armor_surface != null and armor_surface.has_node("ArmorStore"):
		if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE: armor_surface.get_node("ArmorStore").queue_free()
		return
	if get_current_mode() == GameFlowController.MODE_TACTICAL_ACTIVE and event is InputEventKey:
		var view = get_node_or_null("TacticalBattleView")
		if tactical_orders_controller != null and view != null and tactical_orders_controller.handle_input(view, event):
			get_viewport().set_input_as_handled()
			return
	if event is InputEventKey:
		var key_event: InputEventKey = event as InputEventKey
		if not key_event.pressed or key_event.echo:
			return
		if key_event.keycode == KEY_T:
			advance_campaign_turn()
			return
		if key_event.keycode == KEY_H:
			_clear_pending_manual_playtest_seed()
			debug_launch_test_hq_assault()
			return
		if key_event.keycode == KEY_R:
			_debug_launch_manual_playtest_hq_assault()
			return
		if key_event.keycode == KEY_B:
			_debug_enter_pending_battle()
			return
		if key_event.keycode == KEY_C:
			_route_tactical_deployment_commit()
			return
		if key_event.keycode == KEY_SPACE:
			_debug_request_tactical_active()
			return
		if key_event.keycode == KEY_ESCAPE:
			_route_tactical_escape()
			return
	_route_tactical_pointer_input(event)


func _bind_campaign_map_view() -> void:
	var map_view: CampaignMapView = get_node_or_null("CampaignMapView") as CampaignMapView
	if map_view == null:
		return
	map_view.bind_campaign(game_state, game_flow_controller)


func _sync_presentation_views() -> void:
	var mode: String = get_current_mode()
	var show_tactical: bool = (
		mode == GameFlowController.MODE_TACTICAL_DEPLOYMENT
		or mode == GameFlowController.MODE_TACTICAL_ACTIVE
		or mode == GameFlowController.MODE_TACTICAL_PENDING_HANDOFF
	)
	var map_view: CampaignMapView = get_node_or_null("CampaignMapView") as CampaignMapView
	var tactical_view: TacticalBattleView = get_node_or_null("TacticalBattleView") as TacticalBattleView
	if map_view != null:
		map_view.visible = not show_tactical
		map_view.set_presentation_camera_enabled(not show_tactical)
	if tactical_view != null:
		tactical_view.visible = show_tactical
		if show_tactical:
			tactical_view.bind_session(get_current_session())
		else:
			tactical_view.bind_session(null)
		tactical_view.set_presentation_camera_enabled(show_tactical)
	_sync_tactical_deployment_controller(mode, tactical_view)
	_sync_tactical_orders_controller(mode, tactical_view)


func _sync_tactical_deployment_controller(mode: String, tactical_view: TacticalBattleView) -> void:
	var in_deployment: bool = mode == GameFlowController.MODE_TACTICAL_DEPLOYMENT
	if in_deployment:
		if tactical_deployment_controller == null:
			tactical_deployment_controller = TacticalDeploymentController.new()
		if tactical_deployment_controller.session != get_current_session():
			tactical_deployment_controller.bind_session(get_current_session())
		else:
			tactical_deployment_controller.sync_from_authority()
		if tactical_view != null:
			tactical_view.bind_deployment_controller(tactical_deployment_controller)
		return
	if tactical_deployment_controller != null:
		tactical_deployment_controller.clear_selection()
		tactical_deployment_controller.bind_session(null)
	if tactical_view != null:
		tactical_view.bind_deployment_controller(null)


func _route_tactical_escape() -> void:
	if get_current_mode() == GameFlowController.MODE_TACTICAL_DEPLOYMENT:
		_route_tactical_deployment_escape()
		return
	if get_current_mode() != GameFlowController.MODE_TACTICAL_ACTIVE:
		return
	if tactical_orders_controller == null:
		return
	tactical_orders_controller.clear_selection()


func _sync_tactical_orders_controller(mode: String, tactical_view: TacticalBattleView) -> void:
	var in_active: bool = mode == GameFlowController.MODE_TACTICAL_ACTIVE
	if in_active:
		if tactical_orders_controller == null:
			tactical_orders_controller = TacticalOrdersController.new()
		if tactical_orders_controller.session != get_current_session():
			tactical_orders_controller.bind_session(get_current_session())
		else:
			tactical_orders_controller.sync_from_authority()
		if tactical_view != null:
			tactical_view.bind_orders_controller(tactical_orders_controller)
		return
	if tactical_orders_controller != null:
		tactical_orders_controller.clear_selection()
		tactical_orders_controller.bind_session(null)
	if tactical_view != null:
		tactical_view.bind_orders_controller(null)


func _sync_tactical_pointer() -> void:
	var tactical_view: TacticalBattleView = get_node_or_null("TacticalBattleView") as TacticalBattleView
	if tactical_view == null or tactical_view.get_viewport() == null:
		return
	var pointer: Vector2 = tactical_view.get_viewport().get_mouse_position()
	tactical_view.set_pointer_local_position(tactical_view.viewport_to_local_position(pointer))


func _sync_tactical_orders_pointer() -> void:
	if get_current_mode() != GameFlowController.MODE_TACTICAL_ACTIVE:
		return
	if tactical_orders_controller != null:
		tactical_orders_controller.sync_from_authority()
	_sync_tactical_pointer()


func _route_tactical_pointer_input(event: InputEvent) -> void:
	if get_current_mode() == GameFlowController.MODE_TACTICAL_DEPLOYMENT:
		_route_tactical_deployment_input(event)
		return
	if get_current_mode() != GameFlowController.MODE_TACTICAL_ACTIVE:
		return
	_route_tactical_orders_input(event)


func _route_tactical_orders_input(event: InputEvent) -> void:
	var view = get_node_or_null("TacticalBattleView")
	if tactical_orders_controller != null and view != null:
		if tactical_orders_controller.handle_input(view, event):
			get_viewport().set_input_as_handled()


func _handle_tactical_orders_local_click(local_pos: Vector2, button_index: MouseButton) -> void:
	var view = get_node_or_null("TacticalBattleView")
	if tactical_orders_controller == null or view == null:
		return
	if button_index == MOUSE_BUTTON_RIGHT:
		tactical_orders_controller.clear_selection()
	elif button_index == MOUSE_BUTTON_LEFT:
		tactical_orders_controller.click_world(view, view.get_global_transform_with_canvas() * local_pos)


func _route_tactical_deployment_escape() -> void:
	if get_current_mode() != GameFlowController.MODE_TACTICAL_DEPLOYMENT:
		return
	if tactical_deployment_controller == null:
		return
	tactical_deployment_controller.clear_selection()


func _route_tactical_deployment_commit() -> void:
	if get_current_mode() != GameFlowController.MODE_TACTICAL_DEPLOYMENT:
		return
	if tactical_deployment_controller == null:
		return
	tactical_deployment_controller.try_commit_attacker()


func _route_tactical_deployment_input(event: InputEvent) -> void:
	if get_current_mode() != GameFlowController.MODE_TACTICAL_DEPLOYMENT:
		return
	if tactical_deployment_controller == null:
		return
	if not (event is InputEventMouseButton):
		return
	var mouse: InputEventMouseButton = event as InputEventMouseButton
	if not mouse.pressed:
		return
	if mouse.button_index == MOUSE_BUTTON_RIGHT:
		tactical_deployment_controller.clear_selection()
		return
	if mouse.button_index != MOUSE_BUTTON_LEFT:
		return
	var tactical_view: TacticalBattleView = get_node_or_null("TacticalBattleView") as TacticalBattleView
	if tactical_view == null:
		return
	var local_pos: Vector2 = tactical_view.viewport_to_local_position(mouse.position)
	tactical_view.set_pointer_local_position(local_pos)
	_handle_tactical_deployment_local_click(local_pos, mouse.button_index)


func _handle_tactical_deployment_local_click(local_pos: Vector2, button_index: MouseButton) -> void:
	if get_current_mode() != GameFlowController.MODE_TACTICAL_DEPLOYMENT:
		return
	if tactical_deployment_controller == null:
		return
	var tactical_view: TacticalBattleView = get_node_or_null("TacticalBattleView") as TacticalBattleView
	if tactical_view == null:
		return
	if button_index == MOUSE_BUTTON_RIGHT:
		tactical_deployment_controller.clear_selection()
		return
	if button_index != MOUSE_BUTTON_LEFT:
		return
	var hud_hit: Dictionary = tactical_view.hit_test_unit_hud(local_pos)
	if not hud_hit.is_empty():
		var hud_id: String = str(hud_hit.get("id", ""))
		if bool(hud_hit.get("can_select", false)):
			tactical_deployment_controller.select_participant(hud_id)
		return
	if tactical_view.hit_test_confirm_control(local_pos):
		_confirm_current_deployment()
		return
	if tactical_view.DEBUG_DRAW_DEVELOPER_OVERLAY:
		var roster_hit: Dictionary = tactical_view.hit_test_roster(local_pos)
		var kind: String = str(roster_hit.get("kind", ""))
		var hit_id: String = str(roster_hit.get("id", ""))
		if kind == "participant":
			tactical_deployment_controller.select_participant(hit_id)
			return
		if kind == "vehicle":
			tactical_deployment_controller.notify_vehicle_not_available(hit_id)
			return
	var placed_id: String = tactical_view.hit_test_placed_attacker_soldier(local_pos)
	if not placed_id.is_empty():
		tactical_deployment_controller.select_participant(placed_id)
		return
	if tactical_deployment_controller.selected_participant_id.is_empty():
		return
	var cover_object_id: String = tactical_view.hit_test_cover_object(local_pos)
	if not cover_object_id.is_empty():
		tactical_deployment_controller.try_place_selected_cover(cover_object_id)
		return
	var tactical_pos: Vector2 = local_pos / TacticalBattleView.TACTICAL_PIXELS_PER_UNIT
	tactical_deployment_controller.try_place_selected(tactical_pos)


func _confirm_current_deployment() -> void:
	if get_current_mode() != GameFlowController.MODE_TACTICAL_DEPLOYMENT:
		return
	if tactical_deployment_controller == null:
		return
	var session: CampaignBattleSession = get_current_session()
	if session == null or session.battle_state == null:
		return
	var battle_state: BattleState = session.battle_state
	if not battle_state.is_side_deployment_committed(battle_state.attacker_side_id):
		var committed = tactical_deployment_controller.try_commit_attacker()
		if committed == null or not committed.success:
			return
	begin_current_battle()


func _debug_request_tactical_active() -> void:
	var result: GameFlowResult = begin_current_battle()
	if result != null and result.success:
		print(
			"GameplayRuntime: begin_current_battle success mode=%s"
			% get_current_mode()
		)
		_log_tactical_snapshot()
		return
	if result != null:
		print("GameplayRuntime: begin_current_battle failed code=%s" % result.error_code)
		return
	print("GameplayRuntime: begin_current_battle failed")


func _debug_enter_pending_battle() -> void:
	var result: GameFlowResult = enter_battle()
	if result != null and result.success:
		print(
			"GameplayRuntime: enter_battle success mission=%s mode=%s"
			% [result.entered_mission_id, get_current_mode()]
		)
		_log_tactical_snapshot()
	elif result != null:
		print("GameplayRuntime: enter_battle failed code=%s" % result.error_code)
	else:
		print("GameplayRuntime: enter_battle failed")


func _log_tactical_snapshot() -> void:
	var session: CampaignBattleSession = get_current_session()
	if session == null or session.battle_state == null:
		print("GameplayRuntime: tactical snapshot session=absent")
		return
	var battle_state: BattleState = session.battle_state
	var deployed_participants: int = 0
	var undeployed_participants: int = 0
	for participant_id: String in battle_state.participants:
		if battle_state.is_participant_deployed(participant_id):
			deployed_participants += 1
		else:
			undeployed_participants += 1
	var deployed_vehicles: int = 0
	var undeployed_vehicles: int = 0
	for vehicle_id: String in battle_state.vehicles:
		if battle_state.is_vehicle_deployed(vehicle_id):
			deployed_vehicles += 1
		else:
			undeployed_vehicles += 1
	var geo_w: float = 0.0
	var geo_h: float = 0.0
	if battle_state.battlefield_geometry != null:
		geo_w = battle_state.battlefield_geometry.width
		geo_h = battle_state.battlefield_geometry.height
	print(
		"GameplayRuntime: tactical snapshot type=%s mission=%s phase=%s session=%s elapsed=%s geo=%sx%s participants deployed=%s undeployed=%s vehicles deployed=%s undeployed=%s"
		% [
			battle_state.battle_type_id,
			battle_state.mission_id,
			battle_state.battle_phase,
			session.session_state,
			battle_state.elapsed_time_seconds,
			geo_w,
			geo_h,
			deployed_participants,
			undeployed_participants,
			deployed_vehicles,
			undeployed_vehicles,
		]
	)


func get_current_mode() -> String:
	if game_flow_controller == null:
		return ""
	return game_flow_controller.get_current_mode()


func list_pending_battles() -> Array[String]:
	if game_flow_controller == null:
		var empty: Array[String] = []
		return empty
	return game_flow_controller.list_pending_battle_ids()


func get_current_session() -> CampaignBattleSession:
	if game_flow_controller == null:
		return null
	return game_flow_controller.current_session


func advance_campaign_turn() -> GameFlowResult:
	if game_flow_controller == null:
		return GameFlowResult.failed(
			"null_controller",
			"GameplayRuntime failed: GameFlowController is missing."
		)
	var result: GameFlowResult = game_flow_controller.advance_campaign_turn()
	_log_mode_if_changed()
	_log_debug_force_campaign_position("after_turn")
	return result


func enter_battle(mission_id: String = "") -> GameFlowResult:
	if game_flow_controller == null:
		return GameFlowResult.failed(
			"null_controller",
			"GameplayRuntime failed: GameFlowController is missing."
		)
	var result: GameFlowResult = game_flow_controller.enter_pending_battle(mission_id)
	_log_mode_if_changed()
	if result != null and result.success:
		_apply_pending_manual_playtest_seed()
	return result


func begin_current_battle() -> GameFlowResult:
	if game_flow_controller == null:
		return GameFlowResult.failed(
			"null_controller",
			"GameplayRuntime failed: GameFlowController is missing."
		)
	var presentation_view=get_node_or_null("TacticalBattleView")
	if not skip_battle_cinematics and presentation_view!=null and presentation_view._is_dusk_street():
		var presentation=presentation_view.battle_presentation
		if presentation!=null:
			presentation._process(0.)
			if not presentation.can_start():return GameFlowResult.failed("arrival_not_ready","Finish deployment and arrival before starting combat.")
	if tactical_deployment_controller != null:
		tactical_deployment_controller.apply_pending_cover_to_live()
	var result: GameFlowResult = game_flow_controller.begin_current_battle()
	_log_mode_if_changed()
	return result


# Temporary debug path. Uses NeighborhoodHQAttackService; not a production order UI.
func debug_launch_test_hq_assault() -> NeighborhoodHQAttackResult:
	if game_state == null:
		return NeighborhoodHQAttackResult.failed(
			"null_game_state",
			"GameplayRuntime debug HQ assault failed: game_state is null."
		)
	var soldier_ids: Array[String] = StarterWorldService.debug_attacker_soldier_ids()
	var vehicle_ids: Array[String] = []
	vehicle_ids.append(StarterWorldService.VEHICLE_ID)
	var deployment: DeploymentRequest = DeploymentRequest.new(
		StarterWorldService.DEBUG_FORCE_ID,
		StarterWorldService.PLAYER_FACTION_ID,
		StarterWorldService.KEEP_ID,
		StarterWorldService.HQ_ID,
		soldier_ids,
		vehicle_ids,
		10.0
	)
	var request: MissionRequest = MissionRequest.new(
		StarterWorldService.DEBUG_MISSION_ID,
		"capture_neighborhood_hq",
		deployment
	)
	var result: NeighborhoodHQAttackResult = NeighborhoodHQAttackService.launch_from_stronghold(
		game_state,
		request
	)
	_log_mode_if_changed()
	if result != null and result.success:
		print(
			"GameplayRuntime: debug HQ assault launched mission=%s force=%s state=%s"
			% [result.mission_id, result.force_id, result.mission_state]
		)
	elif result != null:
		print(
			"GameplayRuntime: debug HQ assault failed code=%s"
			% result.error_code
		)
	_log_debug_force_campaign_position("after_launch")
	return result


func _debug_launch_manual_playtest_hq_assault() -> NeighborhoodHQAttackResult:
	if _debug_proving_ground_should_restore():
		_restore_debug_proving_ground_world()
	_stamp_next_manual_playtest_seed()
	var result: NeighborhoodHQAttackResult = debug_launch_test_hq_assault()
	if (
		(result == null or not result.success)
		and not StarterWorldService.debug_hq_assault_in_progress(game_state)
	):
		_restore_debug_proving_ground_world()
		result = debug_launch_test_hq_assault()
	_apply_pending_manual_playtest_seed()
	print(
		"GameplayRuntime: manual playtest serial=%d seed=%d"
		% [manual_playtest_serial, _pending_or_session_seed()]
	)
	return result


func _debug_proving_ground_should_restore() -> bool:
	var mode: String = get_current_mode()
	if (
		mode == GameFlowController.MODE_TACTICAL_DEPLOYMENT
		or mode == GameFlowController.MODE_TACTICAL_ACTIVE
	):
		return false
	if mode == GameFlowController.MODE_TACTICAL_PENDING_HANDOFF:
		return true
	if StarterWorldService.debug_hq_assault_in_progress(game_state):
		return false
	return not StarterWorldService.debug_hq_assault_can_launch(game_state)


func _restore_debug_proving_ground_world() -> bool:
	# Debug proving-ground replay only. Rebuilds the starter fixture via
	# StarterWorldService.create(). Does not change campaign resolution rules.
	# Preserves the process-local manual playtest serial.
	var preserved_serial: int = manual_playtest_serial
	var preserved_pending_serial: int = _pending_manual_playtest_serial
	var preserved_pending_seed: int = _pending_combat_seed_override
	if tactical_deployment_controller != null:
		tactical_deployment_controller.clear_selection()
		tactical_deployment_controller.bind_session(null)
	if tactical_orders_controller != null:
		tactical_orders_controller.clear_selection()
		tactical_orders_controller.bind_session(null)
	if game_flow_controller != null:
		game_flow_controller.current_session = null
	var restored: GameState = StarterWorldService.create()
	if restored == null:
		push_error("GameplayRuntime: debug proving-ground restore failed: StarterWorldService.create returned null.")
		return false
	var create_result: GameFlowResult = GameFlowController.create(restored)
	if create_result == null or not create_result.success or create_result.controller == null:
		push_error("GameplayRuntime: debug proving-ground restore failed: GameFlowController could not be created.")
		return false
	game_state = restored
	game_flow_controller = create_result.controller
	manual_playtest_serial = preserved_serial
	_pending_manual_playtest_serial = preserved_pending_serial
	_pending_combat_seed_override = preserved_pending_seed
	_last_logged_mode = ""
	_bind_campaign_map_view()
	_sync_presentation_views()
	_log_mode_if_changed()
	print(
		"GameplayRuntime: restored debug proving-ground world serial=%d turn=%d"
		% [manual_playtest_serial, game_state.current_turn]
	)
	return true


func _stamp_next_manual_playtest_seed() -> void:
	manual_playtest_serial += 1
	_pending_manual_playtest_serial = manual_playtest_serial
	var battle_id: String = "battle_%s" % StarterWorldService.DEBUG_MISSION_ID
	_pending_combat_seed_override = BattleCombatRandom.seed_from_string(
		"%s#manual_%d" % [battle_id, manual_playtest_serial]
	)


func _clear_pending_manual_playtest_seed() -> void:
	_pending_manual_playtest_serial = 0
	_pending_combat_seed_override = 0


func _apply_pending_manual_playtest_seed() -> void:
	if _pending_manual_playtest_serial <= 0:
		return
	var session: CampaignBattleSession = get_current_session()
	if session == null or session.battle_state == null:
		return
	if session.battle_state.battle_phase != "deployment":
		return
	session.has_combat_seed_override = true
	session.combat_seed_override = _pending_combat_seed_override
	session.manual_playtest_serial = _pending_manual_playtest_serial
	session.battle_state.apply_combat_seed(_pending_combat_seed_override)
	print(
		"GameplayRuntime: applied playtest seed serial=%d seed=%d battle_id=%s"
		% [
			_pending_manual_playtest_serial,
			_pending_combat_seed_override,
			session.battle_state.battle_id,
		]
	)
	_clear_pending_manual_playtest_seed()


func _pending_or_session_seed() -> int:
	if _pending_combat_seed_override != 0:
		return _pending_combat_seed_override
	var session: CampaignBattleSession = get_current_session()
	if session != null and session.has_combat_seed_override:
		return session.combat_seed_override
	return 0


func _log_debug_force_campaign_position(reason: String) -> void:
	if game_state == null:
		return
	var force: TravelingForce = game_state.get_traveling_force(StarterWorldService.DEBUG_FORCE_ID)
	if force == null:
		print("GameplayRuntime: %s force=absent pending=%s" % [reason, ",".join(PackedStringArray(list_pending_battles()))])
		return
	var pos: Vector2 = CampaignMapView.campaign_position_of_force(force, game_state.road_graph)
	print(
		"GameplayRuntime: %s force=%s state=%s campaign_pos=(%s, %s) segment=%s into=%s pending=%s"
		% [
			reason,
			force.id,
			force.travel_state,
			pos.x,
			pos.y,
			force.route_segment_index,
			force.distance_into_segment,
			",".join(PackedStringArray(list_pending_battles())),
		]
	)


func _log_boot() -> void:
	var player_id: String = ""
	var turn: int = 0
	if game_flow_controller != null:
		player_id = game_flow_controller.player_faction_id
	if game_state != null:
		turn = game_state.current_turn
	var pending: PackedStringArray = PackedStringArray(list_pending_battles())
	print(
		"GameplayRuntime: booted mode=%s turn=%s player=%s pending=%s"
		% [get_current_mode(), turn, player_id, ",".join(pending)]
	)


func _log_mode_if_changed() -> void:
	var mode: String = get_current_mode()
	if mode == _last_logged_mode:
		return
	_last_logged_mode = mode
	_sync_presentation_views()
	var pending: PackedStringArray = PackedStringArray(list_pending_battles())
	print("GameplayRuntime: mode=%s pending=%s" % [mode, ",".join(pending)])

func _build_armor_store() -> void:
	armor_layer=CanvasLayer.new();armor_layer.layer=70;add_child(armor_layer)
	armor_surface=Control.new();armor_layer.add_child(armor_surface);armor_surface.size=Vector2(1152,860);armor_surface.mouse_filter=Control.MOUSE_FILTER_IGNORE
	armor_button=Button.new();armor_surface.add_child(armor_button);armor_button.position=Vector2(960,18);armor_button.size=Vector2(160,38);armor_button.text="ARMOR STORE"
	armor_button.pressed.connect(func():
		if get_current_mode()!=GameFlowController.MODE_CAMPAIGN or armor_surface.has_node("ArmorStore"):return
		var panel=ArmorPanel.new();panel.name="ArmorStore";panel.configure(game_state,StarterWorldService.PLAYER_FACTION_ID,false);armor_surface.add_child(panel))
	_sync_armor_store()
func _sync_armor_store() -> void:
	if armor_layer==null:return
	var campaign: bool=get_current_mode()==GameFlowController.MODE_CAMPAIGN
	armor_layer.visible=campaign
	if not campaign and armor_surface.has_node("ArmorStore"):armor_surface.get_node("ArmorStore").queue_free()
	var viewport=get_viewport().get_visible_rect().size
	var factor=minf(viewport.x/1152.,viewport.y/860.)
	armor_surface.scale=Vector2.ONE*factor;armor_surface.position=(viewport-Vector2(1152,860)*factor)*.5
