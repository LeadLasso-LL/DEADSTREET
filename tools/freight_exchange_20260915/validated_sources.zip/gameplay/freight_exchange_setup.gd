extends RefCounted
const C=preload("res://battle/geometry/freight_exchange_catalog.gd")
const Authored=preload("res://battle/geometry/authored_battlefield_service.gd")
const Place=preload("res://battle/vehicles/battle_vehicle_placement_service.gd")
const Units=preload("res://battle/core/battle_deployment_placement_service.gd")
const Doors=preload("res://battle/vehicles/battle_arrival_service.gd")
const Cover=preload("res://battle/geometry/battle_cover_service.gd")
const Exit=preload("res://battle/vehicles/battle_vehicle_exit_service.gd")
static func apply(b,_config: Dictionary) -> Dictionary:
 var result=Authored.apply_definition(b,C.build())
 if result==null or not result.success:return {"error":"Freight Exchange geometry failed validation."}
 b.vehicle_hidden_cover_slots.clear()
 for side in [b.attacker_side_id,b.defender_side_id]:
  b.get_side(side).deployment_committed=false
  var zone=b.get_deployment_zone(b.get_side(side).deployment_zone_id)
  zone.deployed_vehicle_ids.clear();zone.deployed_participant_ids.clear()
 for p in b.participants.values():
  p.has_battle_position=false;p.deployment_slot_id="";p.occupied_cover_slot_id="";p.reserved_cover_slot_id="";p.clear_player_tactical_intent()
 var vehicles=b.vehicles.values();vehicles.sort_custom(func(a,z):return a.battle_vehicle_id<z.battle_vehicle_id)
 for v in vehicles:v.has_battle_position=false;v.deployment_slot_id=""
 for v in vehicles:
  var n=int(v.get_meta("convoy_slot",0));var member=int(v.get_meta("convoy_member",0))
  var y=[15.,37.,62.][clampi(n,0,2)]
  var poses=[[Vector2(13.+member*5.,y),Vector2.UP],[Vector2(8.+member*5.,y),Vector2.UP]]
  var placed=false
  for pose in poses:
   var attempt=Place.place_vehicle(b,v.battle_vehicle_id,pose[0],pose[1])
   if attempt!=null and attempt.success:placed=true;break
  if not placed:return {"error":"This convoy cannot fit the freight receiving road. Choose smaller vehicles."}
 for v in vehicles:Doors.ensure_doors(b,v)
 b.arrival_choice="freight_exchange_assault";b.battlefield_geometry.content_revision+=1
 if not deploy(b,b.defender_side_id):return {"error":"Freight Exchange defenders could not reach safe cover."}
 if not b.commit_side_deployment(b.defender_side_id):return {"error":"Freight Exchange defender deployment failed."}
 return {"valid":true}
static func deploy(b,side: String) -> bool:
 var ids=b.participants.keys();ids.sort();var i=0
 for id in ids:
  var p=b.get_participant(id)
  if p.side_id!=side or p.has_battle_position:continue
  var attacking=side==b.attacker_side_id;var v=b.get_vehicle(p.transport_vehicle_id)
  var lane=[16.,35.,53.,65.][i%4]
  var goal=Vector2(39 if attacking else 140,lane)
  var facing=Vector2.RIGHT if attacking else Vector2.LEFT
  var slots=b.battlefield_geometry.cover_slots.values()
  slots.sort_custom(func(a,z):return a.position.distance_squared_to(goal)<z.position.distance_squared_to(goal))
  var placed=false
  for slot in slots:
   if slot.is_occupied() or slot.is_reserved() or slot.facing_direction.dot(facing)<-.1:continue
   if not b.get_deployment_position_error(side,slot.position).is_empty():continue
   var crowded=false
   for q in b.participants.values():
    if q.has_battle_position and q.battle_position.distance_to(slot.position)<2.4:crowded=true;break
   if crowded:continue
   if attacking:
    if v==null:continue
    var route=Exit.route(b,v,slot.position,bool(p.get_meta("transport_bed",false)))
    if route.is_empty() or not route.path.success:continue
   var attempt=Units.place_participant(b,id,slot.position)
   if attempt!=null and attempt.success:
    var occupied=Cover.occupy_slot(b,id,slot.cover_slot_id)
    if occupied!=null and occupied.success:
     p.set_meta("freight_opening_cover",slot.cover_slot_id);placed=true;break
  if not placed:return false
  i+=1
 return true
static func arrival_pose(v,clock: float,stop: float) -> Dictionary:
 var target: Vector2=v.battle_position
 var start=Vector2(target.x,105.+float(v.get_meta("convoy_slot",0))*15.)
 return {"position":start.lerp(target,smoothstep(1.6,stop,clock)),"facing":v.facing_direction}
