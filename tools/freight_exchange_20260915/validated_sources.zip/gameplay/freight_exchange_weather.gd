extends Node2D
## Map-local night/rain presentation; HUD, tactics and other maps stay independent.
const C=preload("res://battle/geometry/freight_exchange_catalog.gd")
const LIGHTS=[
 [Vector2(25,-2),Color("#ffd296"),1.05,1.7],
 [Vector2(110,-2),Color("#b3d3df"),.82,1.85],
 [Vector2(165,16),Color("#ffd093"),1.12,1.65],
 [Vector2(165,58),Color("#b4d2df"),.92,1.8],
 [Vector2(27,78),Color("#ffd093"),1.05,1.75],
 [Vector2(108,78),Color("#ffd59f"),1.05,1.85],
 [Vector2(141,20),Color("#ffc77e"),.82,1.0],
 [Vector2(70,12),Color("#ffd296"),1.0,1.55],
 [Vector2(96,57),Color("#b6d8e1"),.83,1.45]
]
var view
var tick=0.
var drops=[]
var splashes=[]
var rain: AudioStreamPlayer
var roof: AudioStreamPlayer2D
var lights=[]
var sound_enabled=true
var rng=RandomNumberGenerator.new()
func _ready():
 z_index=90;texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
 var material_value=CanvasItemMaterial.new();material_value.light_mode=CanvasItemMaterial.LIGHT_MODE_UNSHADED;material=material_value
 var night=CanvasModulate.new();night.color=Color(.38,.46,.56);add_child(night)
 var gradient=Gradient.new();gradient.offsets=PackedFloat32Array([0.,.18,.50,1.]);gradient.colors=PackedColorArray([Color(1,1,1,1),Color(1,1,1,.85),Color(1,1,1,.36),Color(1,1,1,0)])
 var glow=GradientTexture2D.new();glow.gradient=gradient;glow.width=256;glow.height=256;glow.fill=GradientTexture2D.FILL_RADIAL;glow.fill_from=Vector2(.5,.5);glow.fill_to=Vector2(1.,.5)
 for spec in LIGHTS:
  var lamp=PointLight2D.new();lamp.texture=glow;lamp.color=spec[1];lamp.energy=spec[2];lamp.texture_scale=spec[3]
  lamp.position=spec[0]*Vector2(8,6)+Vector2(11,-44) if spec[0].y!=20 else spec[0]*Vector2(8,6)
  lamp.shadow_enabled=true;lamp.shadow_color=Color(.025,.045,.065,.64);lamp.shadow_filter=Light2D.SHADOW_FILTER_PCF5
  add_child(lamp);lights.append(lamp)
 # Physical boxes cast local shadows into the wet lanes. No scene-wide dark overlay.
 for row in C.props():
  if row[2] not in ["boxcar","timber_car","dispatch","shed"]:continue
  var b: Rect2=row[1];var q=b.position*Vector2(8,6);var end=b.end*Vector2(8,6)
  var polygon=OccluderPolygon2D.new();polygon.polygon=PackedVector2Array([q,Vector2(end.x,q.y),end,Vector2(q.x,end.y)])
  var occluder=LightOccluder2D.new();occluder.occluder=polygon;add_child(occluder)
 rng.seed=925523
 for i in range(610):drops.append([Vector2(rng.randf_range(-850,2150),rng.randf_range(-580,1120)),rng.randf_range(235,340),rng.randf_range(5,12),rng.randf_range(.055,.18)])
 for i in range(70):splashes.append([Vector2(rng.randf_range(205,1310),rng.randf_range(5,450)),rng.randf()])
 rain=AudioStreamPlayer.new();add_child(rain);rain.stream=loop_stream("res://assets/audio/ambience/freight_rain.wav");rain.volume_db=-13.
 if rain.stream!=null:rain.play()
 roof=AudioStreamPlayer2D.new();add_child(roof);roof.stream=loop_stream("res://assets/audio/ambience/freight_roof_rain.wav");roof.position=Vector2(97,26)*Vector2(8,6);roof.max_distance=1200.;roof.attenuation=.65;roof.volume_db=-21.
 if roof.stream!=null:roof.play()
func loop_stream(path: String) -> AudioStreamWAV:
 if not FileAccess.file_exists(path):return null
 var stream=AudioStreamWAV.load_from_file(path)
 if stream!=null:stream.loop_mode=AudioStreamWAV.LOOP_FORWARD;stream.loop_begin=0;stream.loop_end=int(round(stream.get_length()*stream.mix_rate))
 return stream
func _process(delta):
 tick+=delta
 var active=sound_enabled
 if view!=null and is_instance_valid(view):active=active and view.visible and view.battle_presentation.audio_enabled and view._is_dusk_street() and view._geometry().authored_layout_id==C.ID
 if rain!=null:rain.stream_paused=not active
 if roof!=null:roof.stream_paused=not active
 queue_redraw()
func _draw():
 # Occupied dispatch windows cast a subdued amber glow through dirty glass.
 for at in [Vector2(1024,86),Vector2(1247,86)]:
  draw_rect(Rect2(at,Vector2(21,10)),Color(.72,.51,.23,.42))
  draw_line(at+Vector2(10,0),at+Vector2(10,10),Color(.17,.22,.20,.8),1.)
 # Lamp lenses and restrained wet glints stay luminous within the night canvas.
 for i in range(LIGHTS.size()):
  var spec=LIGHTS[i];var at: Vector2=spec[0]*Vector2(8,6)
  var bulb=at+Vector2(11,-46) if spec[0].y!=20 else at-Vector2(0,10)
  for radius in [9.,5.,2.]:draw_circle(bulb,radius,Color(spec[1],.035 if radius==9. else .10 if radius==5. else .7))
  for n in range(12):
   var y=n*4.;var x=sin(float(n)*4.7+i)*14.
   var shimmer=.045+sin(tick*2.+n)*.015
   draw_line(at+Vector2(x-5,8+y),at+Vector2(x+5+n*.5,8+y),Color(spec[1],shimmer),1.)
 for drop in drops:
  var at: Vector2=drop[0];var speed: float=drop[1]
  at.x=fposmod(at.x-850.-tick*speed*.20,3000.)-850.
  at.y=fposmod(at.y+580.+tick*speed,1700.)-580.
  var alpha: float=drop[3]
  # Rain briefly catches a yard lamp as it falls through its cone.
  for lamp in lights:
   if at.distance_squared_to(lamp.position)<9000.:alpha*=1.7;break
  draw_line(at,at+Vector2(-drop[2]*.20,drop[2]),Color(.61,.75,.85,alpha),.7)
 for splash in splashes:
  var phase=fposmod(tick*.95+float(splash[1]),1.)
  if phase>.28:continue
  var at: Vector2=splash[0]
  draw_arc(at,1.+phase*7.,0,TAU,8,Color(.60,.75,.80,(.28-phase)*.18),.7)
